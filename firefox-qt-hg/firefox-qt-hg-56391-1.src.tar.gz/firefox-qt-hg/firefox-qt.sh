#!/bin/sh
exec /usr/lib/firefox-4.0b8pre/firefox $*

