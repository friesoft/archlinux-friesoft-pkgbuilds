#!/bin/sh
exec /usr/lib/firefox-4.0b7pre/firefox $*

